package com.example.rassah.think_a_number;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    Button btn_plus,btn_minus,btn_send;
    TextView textView_szam;
    ImageView imageView1,imageView2,imageView3,imageView4,imageView5;

    int szam = 0;
    int kitalalando_szam = 0;
    int probalkozas = 5;

    int min = 0;
    int max = 10;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

         btn_minus = (Button)findViewById(R.id.btn_minus);
         btn_plus = (Button)findViewById(R.id.btn_plus);
         btn_send = (Button)findViewById(R.id.btn_send);

         textView_szam = (TextView)findViewById(R.id.textView_szam);

         imageView1 = (ImageView)findViewById(R.id.imageView_hearth1);
         imageView2 = (ImageView)findViewById(R.id.imageView_hearth2);
         imageView3 = (ImageView)findViewById(R.id.imageView_hearth3);
         imageView4 = (ImageView)findViewById(R.id.imageView_hearth4);
         imageView5 = (ImageView)findViewById(R.id.imageView_hearth5);





        btn_plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(szam > 50){
                    Toast.makeText(getApplicationContext(),"A szám nem lehet nagyobb mint 50",Toast.LENGTH_SHORT).show();
                    szam = 0;
                }
                szam = szam +1;
                textView_szam.setText(String.valueOf(szam));

            }
        });

        btn_minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(szam < 0){
                    szam = 0;
                }
                szam = szam -1;
                textView_szam.setText(String.valueOf(szam));
            }
        });

        btn_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Random r = new Random();
                kitalalando_szam= r.nextInt(max - min + 1) + min;

                int sajat_szam = Integer.parseInt(textView_szam.getText().toString());

                if(sajat_szam == kitalalando_szam){
                    Toast.makeText(getApplicationContext(),"Nyertél",Toast.LENGTH_SHORT).show();
                }
                else {
                    probalkozas = probalkozas -1;
                }

                if(probalkozas == 0){
                    Toast.makeText(getApplicationContext(),"Vesztettél",Toast.LENGTH_SHORT).show();
                    imageView5.setImageResource(R.drawable.heart2);
                    imageView4.setImageResource(R.drawable.heart2);
                    imageView3.setImageResource(R.drawable.heart2);
                    imageView2.setImageResource(R.drawable.heart2);
                    imageView1.setImageResource(R.drawable.heart2);
                    Toast.makeText(getApplicationContext(),"A játék újra indult !",Toast.LENGTH_SHORT).show();
                    probalkozas = 5;
                }


                switch (probalkozas){
                    case 4:
                        imageView5.setImageResource(R.drawable.heart1);
                        break;
                    case 3:
                        imageView4.setImageResource(R.drawable.heart1);
                        break;
                    case 2:
                        imageView3.setImageResource(R.drawable.heart1);
                        break;
                    case 1:
                        imageView2.setImageResource(R.drawable.heart1);
                        break;
                    case 0:
                        imageView1.setImageResource(R.drawable.heart1);
                        break;
                }

                Toast.makeText(getApplicationContext(),String.valueOf(kitalalando_szam),Toast.LENGTH_SHORT).show();
            }
        });

    }
}
